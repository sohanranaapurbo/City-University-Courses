<?php
require_once "config.php";

$booksPerPage = 10;

if (isset($_POST['query'])) {
    $searchQuery = $_POST['query'];
    $currentPage = $_POST['page'];

    $offset = ($currentPage - 1) * $booksPerPage;

    $sql = "SELECT COUNT(*) AS total FROM book WHERE book_name LIKE '%$searchQuery%' OR writer LIKE '%$searchQuery%' OR category LIKE '%$searchQuery%'";
    $result = mysqli_query($link, $sql);
    $row = mysqli_fetch_assoc($result);
    $totalBooks = $row['total'];

    $totalPages = ceil($totalBooks / $booksPerPage);

    $sql = "SELECT * FROM book WHERE book_name LIKE '%$searchQuery%' OR writer LIKE '%$searchQuery%' OR category LIKE '%$searchQuery%' LIMIT $offset, $booksPerPage";
    $result = mysqli_query($link, $sql);

    if (mysqli_num_rows($result) > 0) {
        echo '<table id="search-results" class="table table-bordered table-striped">';
        echo "<thead>";
        echo "<tr>";
        echo "<th>#</th>";
        echo "<th>Name</th>";
        echo "<th>Writer</th>";
        echo "<th>Price</th>";
        echo "<th>Category</th>";
        echo "<th>Action</th>";
        echo "</tr>";
        echo "</thead>";
        echo "<tbody>";
        while ($row = mysqli_fetch_array($result)) {
            echo "<tr>";
            echo "<td>" . $row['book_id'] . "</td>";
            echo "<td>" . $row['book_name'] . "</td>";
            echo "<td>" . $row['writer'] . "</td>";
            echo "<td>" . $row['price'] . "</td>";
            echo "<td>" . $row['category'] . "</td>";
            echo "<td>";
            echo '<a href="read.php?id=' . $row['book_id'] . '" class="mr-3" title="View Record" data-toggle="tooltip"><span class="fa fa-eye"></span></a>';
            echo '<a href="update.php?id=' . $row['book_id'] . '" class="mr-3" title="Update Record" data-toggle="tooltip"><span class="fa fa-pencil"></span></a>';
            echo '<a href="delete.php?id=' . $row['book_id'] . '" title="Delete Record" data-toggle="tooltip"><span class="fa fa-trash"></span></a>';
            echo "</td>";
            echo "</tr>";
        }
        echo "</tbody>";
        echo "</table>";
    } else {
        echo '<div class="alert alert-danger"><em>No books found.</em></div>';
    }

    mysqli_close($link);
}
?>
