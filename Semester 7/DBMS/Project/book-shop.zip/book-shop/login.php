<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Login - Book Shop Management</title>
    <link
      rel="stylesheet"
      href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha2/css/bootstrap.min.css"
    />
    <style>
      body {
        background: url("./img3.jpg") no-repeat center center fixed;
        background-size: cover;
      }

      .login-form {
        max-width: 400px;
        margin: 0 auto;
        margin-top: 100px;
        padding: 20px;
        background-color: rgba(255, 255, 255, 0.8);
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        border-radius: 12px;
      }

      .login-form h2 {
        text-align: center;
      }
      .login-form h3 {
        margin-bottom: 20px;
        text-align: center;
      }

      .login-form .form-control {
        border-radius: 8px;
      }

      .login-form .btn-primary {
        width: 100%;
        border-radius: 8px;
      }
    </style>
  </head>
  <body>
    <div class="container">
      <div class="login-form">
        <h2>Admin Login</h2>
        <h3>Book Shop Management</h3>

        <form action="index.php" method="POST">
          <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input
              type="text"
              name="email"
              id="email"
              class="form-control"
              required
            />
          </div>
          <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input
              type="password"
              name="password"
              id="password"
              class="form-control"
              required
            />
          </div>
          <div class="mb-3 form-check">
            <input type="checkbox" class="form-check-input" id="remember" />
            <label class="form-check-label" for="remember">Remember me</label>
          </div>

          <button type="submit" class="btn btn-primary">Login</button>

        </form>
      </div>
    </div>

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha2/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
