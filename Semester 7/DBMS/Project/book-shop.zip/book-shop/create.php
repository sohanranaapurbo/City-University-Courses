<?php
// Include config file
require_once "config.php";

// Define variables and initialize with empty values
$book_id = '';

$book_name = $quantity = $book_condition = $book_discount = $price = $writer = $category = "";
$book_id_err = $book_name_err = $quantity_err = $book_condition_err = $book_discount_err = $price_err = $writer_err = $category_err = "";

// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate book_id
    // $input_book_id = trim($_POST["book_id"]);

    // if (empty($input_book_id)) {
    //     $book_id_err = "Please enter a book ID.";
    // } elseif (!ctype_digit($input_book_id)) {
    //     $book_id_err = "Please enter a valid book ID.";
    // } else {
    //     $book_id = $input_book_id;
    // }

    // Validate book_name
    $input_book_name = trim($_POST["book_name"]);
    if (empty($input_book_name)) {
        $book_name_err = "Please enter a book name.";
    } else {
        $book_name = $input_book_name;
    }

    // Validate quantity
    $input_quantity = trim($_POST["quantity"]);
    if (empty($input_quantity)) {
        $quantity_err = "Please enter the quantity.";
    } elseif (!ctype_digit($input_quantity)) {
        $quantity_err = "Please enter a positive integer value.";
    } else {
        $quantity = $input_quantity;
    }

    // Validate book_condition
    $input_book_condition = trim($_POST["book_condition"]);
    if (empty($input_book_condition)) {
        $book_condition_err = "Please enter the book condition.";
    } else {
        $book_condition = $input_book_condition;
    }

    // Validate book_discount
    $input_book_discount = trim($_POST["book_discount"]);
    if ($input_book_discount < 0) {
        $book_discount_err = "Please enter the book discount.";
    }else {
        $book_discount = $input_book_discount;
    }

    // Validate price
    $input_price = trim($_POST["price"]);
    if (empty($input_price)) {
        $price_err = "Please enter the price.";
    } elseif (!is_numeric($input_price)) {
        $price_err = "Please enter a numeric value.";
    } else {
        $price = $input_price;
    }

    // Validate writer
    $input_writer = trim($_POST["writer"]);
    if (empty($input_writer)) {
        $writer_err = "Please enter the writer.";
    } else {
        $writer = $input_writer;
    }

    // Validate category
    $input_category = trim($_POST["category"]);
    if (empty($input_category)) {
        $category_err = "Please enter the category.";
    } else {
        $category = $input_category;
    }

    // Check input errors before inserting in database
    if (empty($book_id_err) && empty($book_name_err) && empty($quantity_err) && empty($book_condition_err) && empty($book_discount_err) && empty($price_err) && empty($writer_err) && empty($category_err)) {
        // Prepare an insert statement
        $sql = "INSERT INTO book (book_id, book_name, quantity, book_condition, book_discount, price, writer, category) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        if ($stmt = mysqli_prepare($link, $sql)) {
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ssssssss", $param_book_id, $param_book_name, $param_quantity, $param_book_condition, $param_book_discount, $param_price, $param_writer, $param_category);

            // Set parameters
            $param_book_id = $book_id;
            $param_book_name = $book_name;
            $param_quantity = $quantity;
            $param_book_condition = $book_condition;
            $param_book_discount = $book_discount;
            $param_price = $price;
            $param_writer = $writer;
            $param_category = $category;

            // Attempt to execute the prepared statement
            if (mysqli_stmt_execute($stmt)) {
                // Records created successfully. Redirect to landing page
                header("location: index.php");
                exit();
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }
        }

        // Close statement
        mysqli_stmt_close($stmt);
    }

    // Close connection
    mysqli_close($link);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Create Record</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
    .wrapper {
        width: 600px;
        margin: 0 auto;
        background-color: #AFD3E2;
        border-radius: 12px;
    }
    </style>
</head>

<body>
    <br>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="mt-5">Add a new book</h2>
                    <p>Please fill this form and submit to add a new book record to the database.</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        
                    <!-- <div class="form-group">
                            <label>Book ID</label>
                            <input type="text" name="book_id"
                                class="form-control <?php echo (!empty($book_id_err)) ? 'is-invalid' : ''; ?>"
                                value="<?php echo $book_id; ?>">
                            <span class="invalid-feedback">
                                <?php echo $book_id_err; ?>
                            </span>
                        </div> -->

                        <div class="form-group">
                            <label>Book Name</label>
                            <input type="text" name="book_name"
                                class="form-control <?php echo (!empty($book_name_err)) ? 'is-invalid' : ''; ?>"
                                value="<?php echo $book_name; ?>">
                            <span class="invalid-feedback">
                                <?php echo $book_name_err; ?>
                            </span>
                        </div>
                        <div class="form-group">
                            <label>Quantity</label>
                            <input type="text" name="quantity"
                                class="form-control <?php echo (!empty($quantity_err)) ? 'is-invalid' : ''; ?>"
                                value="<?php echo $quantity; ?>">
                            <span class="invalid-feedback">
                                <?php echo $quantity_err; ?>
                            </span>
                        </div>

                        <div class="form-group">
                            <label>Book Condition</label><br>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="book_condition" value="New"
                                    <?php echo ($book_condition === 'New') ? 'checked' : ''; ?>>
                                <label class="form-check-label">New</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="book_condition" value="Used"
                                    <?php echo ($book_condition === 'Used') ? 'checked' : ''; ?>>
                                <label class="form-check-label">Used</label>
                            </div>
                            <span class="invalid-feedback">
                                <?php echo $book_condition_err; ?>
                            </span>
                        </div>

                        <div class="form-group">
                            <label>Book Discount</label>
                            <input type="text" name="book_discount"
                                class="form-control <?php echo (!empty($book_discount_err)) ? 'is-invalid' : ''; ?>"
                                value="<?php echo $book_discount; ?>">
                            <span class="invalid-feedback">
                                <?php echo $book_discount_err; ?>
                            </span>
                        </div>
                        <div class="form-group">
                            <label>Price</label>
                            <input type="text" name="price"
                                class="form-control <?php echo (!empty($price_err)) ? 'is-invalid' : ''; ?>"
                                value="<?php echo $price; ?>">
                            <span class="invalid-feedback">
                                <?php echo $price_err; ?>
                            </span>
                        </div>
                        <div class="form-group">
                            <label>Writer</label>
                            <input type="text" name="writer"
                                class="form-control <?php echo (!empty($writer_err)) ? 'is-invalid' : ''; ?>"
                                value="<?php echo $writer; ?>">
                            <span class="invalid-feedback">
                                <?php echo $writer_err; ?>
                            </span>
                        </div>

                        <div class="form-group">
                            <label>Category</label>
                            <select name="category"
                                class="form-control <?php echo (!empty($category_err)) ? 'is-invalid' : ''; ?>">
                                <option value="">Select a category</option>
                                <option value="Fiction" <?php echo ($category === 'Fiction') ? 'selected' : ''; ?>>
                                    Fiction</option>
                                <option value="Nonfiction"
                                    <?php echo ($category === 'Non-fiction') ? 'selected' : ''; ?>>Non-fiction</option>
                                <option value="Science" <?php echo ($category === 'Science') ? 'selected' : ''; ?>>
                                    Science</option>
                                <option value="Drama" <?php echo ($category === 'Drama') ? 'selected' : ''; ?>>Drama
                                </option>
                                <option value="Romantic" <?php echo ($category === 'Romantic') ? 'selected' : ''; ?>>
                                    Romantic</option>
                                <option value="History" <?php echo ($category === 'History') ? 'selected' : ''; ?>>
                                    History</option>
                                <!-- Add more options as needed -->
                            </select>
                            <span class="invalid-feedback">
                                <?php echo $category_err; ?>
                            </span>
                        </div>

                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="index.php" class="btn btn-secondary ml-2">Cancel</a>
                    </form>
                    <br>
                </div>
            </div>
        </div>
    </div>
    <br>
</body>
</html>