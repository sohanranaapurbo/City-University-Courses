<?php
// Include config file
require_once "config.php";

// Define variables and initialize with empty values
$book_id = $cust_id = $quantity = "";
$book_id_err = $cust_id_err = $quantity_err = "";

// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Validate book_id
    $input_book_id = trim($_POST["book_id"]);
    if (empty($input_book_id)) {
        $book_id_err = "Please enter a book id.";
    } else {
        $book_id = $input_book_id;
    }

    $input_cust_id = trim($_POST["cust_id"]);
    if (empty($input_cust_id)) {
        $cust_id_err = "Please enter a cust id.";
    } else {
        $cust_id = $input_cust_id;
    }

    // Validate quantity
    $input_quantity = trim($_POST["quantity"]);
    if (empty($input_quantity)) {
        $quantity_err = "Please enter the quantity.";
    } elseif (!ctype_digit($input_quantity)) {
        $quantity_err = "Please enter a positive integer value.";
    } else {
        $quantity = $input_quantity;
    }

    // Check input errors before inserting in database
    if (empty($book_id_err) && empty($cust_id_err) && empty($quantity_err) ) {
        // Prepare an insert statement
        $sql = "INSERT INTO orders (cust_id, date, quantity, book_id) VALUES (?, ?, ?, ?)";

        if ($stmt = mysqli_prepare($link, $sql)) {
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ssss", $param_cust_id, $param_date, $param_quantity, $param_book_id);

            // Set parameters
            $param_cust_id = $cust_id; // Assuming book_id corresponds to cust_id in user_orders table
            $param_date = date('Y-m-d'); // Assuming the current date should be inserted as the order date
            $param_quantity = $quantity;
            $param_book_id = $book_id; // Assuming book_id corresponds to book_id in user_orders table

            // Attempt to execute the prepared statement
            if (mysqli_stmt_execute($stmt)) {
                // Records created successfully. Redirect to landing page
                header("location: orders.php");
                exit();
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }
        }

        // Close statement
        mysqli_stmt_close($stmt);
    }

    // Close connection
    mysqli_close($link);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Create Order</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
    .wrapper {
        width: 600px;
        margin: 0 auto;
        background-color: #AFD3E2;
        border-radius: 12px;
    }
    </style>
</head>

<body>
    <br>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="mt-5">Add a new order</h2>
                    <p>Please fill this form and submit to add a new order record to the database.</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">

                        <div class="form-group">
                            <label>Customer id</label>
                            <input type="text" name="cust_id"
                                class="form-control <?php echo (!empty($cust_id_err)) ? 'is-invalid' : ''; ?>"
                                value="<?php echo $cust_id; ?>">
                            <span class="invalid-feedback"><?php echo $cust_id_err; ?></span>
                        </div>

                        <div class="form-group">
                            <label>Book id</label>
                            <input type="text" name="book_id"
                                class="form-control <?php echo (!empty($book_id_err)) ? 'is-invalid' : ''; ?>"
                                value="<?php echo $book_id; ?>">
                            <span class="invalid-feedback"><?php echo $book_id_err; ?></span>
                        </div>

                        <div class="form-group">
                            <label>Quantity</label>
                            <input type="text" name="quantity"
                                class="form-control <?php echo (!empty($quantity_err)) ? 'is-invalid' : ''; ?>"
                                value="<?php echo $quantity; ?>">
                            <span class="invalid-feedback"><?php echo $quantity_err; ?></span>
                        </div>

                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="orders.php" class="btn btn-secondary ml-2">Cancel</a>
                    </form>
                    <br>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
