<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
    .wrapper {
        width: 70%;
        margin: 0 auto;
        background-color: #AFD3E2;
        border-radius: 12px;
    }

    table tr td:last-child {
        width: 120px;
    }

    table {
        background-color: #E6FFFD;
        /* border-radius: 12px; */
    }

    /* Dashboard */
    .navbar {
        background-color: #343a40;
        padding: 10px 20px;
    }

    .navbar-brand {
        color: #fff;
        font-size: 24px;
    }

    .navbar-nav .nav-link {
        color: #fff;
        font-size: 16px;
        padding: 5px 10px;
    }

    .dashboard {
        display: flex;
    }

    .sidebar {
        width: 30%;
        height: 600px;
        background-color: #E6FFFD;
        padding: 20px;
        border-radius: 12px;
        margin-right: 8px;
    }

    .sidebar h4 {
        margin-bottom: 20px;
        padding: 2px 8px;
    }

    .sidebar ul {
        list-style-type: none;
        padding: 0;
    }

    .sidebar li {
        margin-bottom: 10px;
        padding: 2px 8px;
    }

    .sidebar_li_selected,
    .sidebar_li_unselected:hover {
        margin-bottom: 10px;
        font-weight: bold;
        background-color: #AFD3E2;
        border-radius: 12px;
    }

    .sidebar a {
        text-decoration: none;
        color: #212529;
    }

    .content {
        flex-grow: 1;
        padding: 20px;
    }

    .content h2 {
        margin-bottom: 20px;
    }
    </style>
    <script>
    $(document).ready(function() {
        $('[data-toggle="tooltip"]').tooltip();
    });
    </script>
</head>

<body>

    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand" href="#">Admin dashboard</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Logout (Tahmeedul)</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <br>

    <div class="container dashboard">

        <div class="sidebar">
            <h4>Menu</h4>
            <ul>
                <li class="sidebar_li_unselected"><a href="search.php">Search Book</a></li>
                <li class="sidebar_li_unselected"><a href="index.php">Manage Books</a></li>
                <li class="sidebar_li_selected"><a href="orders.php">Manage Orders</a></li>
            </ul>
        </div>



        <div class="wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="mt-5 mb-3 clearfix">
                            <h2 class="pull-left">All Orders</h2>
                            <a href="create_order.php" class="btn btn-success pull-right"><i class="fa fa-plus"></i> Add New
                                Order</a>
                        </div>

                        <?php
                    // Include config file
                    require_once "config.php";

                    // Define how many orders to display per page
                    $ordersPerPage = 6;

                    // Get the current page from the query string
                    if (isset($_GET['page'])) {
                        $currentPage = $_GET['page'];
                    } else {
                        $currentPage = 1;
                    }

                    // Calculate the offset for the query
                    $offset = ($currentPage - 1) * $ordersPerPage;

                    // Count total number of orders
                    $sql = "SELECT COUNT(*) AS total FROM orders";
                    $result = mysqli_query($link, $sql);
                    $row = mysqli_fetch_assoc($result);
                    $totalOrders = $row['total'];

                    // Calculate total number of pages
                    $totalPages = ceil($totalOrders / $ordersPerPage);

                    // Retrieve orders for the current page
                    $sql = "SELECT * FROM orders LIMIT $offset, $ordersPerPage";
                    $result = mysqli_query($link, $sql);

                    // Display order records
                    if (mysqli_num_rows($result) > 0) {
                        echo '<table class="table table-bordered table-striped">';
                        echo "<thead>";
                        echo "<tr>";
                        echo "<th>#</th>";
                        echo "<th>Customer ID</th>";
                        echo "<th>Date</th>";
                        echo "<th>Quantity</th>";
                        echo "<th>Book ID</th>";
                        echo "<th>Action</th>";
                        echo "</tr>";
                        echo "</thead>";
                        echo "<tbody>";
                        while ($row = mysqli_fetch_array($result)) {
                            echo "<tr>";
                            echo "<td>" . $row['id'] . "</td>";
                            echo "<td>" . $row['cust_id'] . "</td>";
                            echo "<td>" . $row['date'] . "</td>";
                            echo "<td>" . $row['quantity'] . "</td>";
                            echo "<td>" . $row['book_id'] . "</td>";
                            echo "<td>";
                            echo '<a href="update_order.php?id=' . $row['id'] . '" class="mr-3" title="Update Record" data-toggle="tooltip"><span class="fa fa-pencil"></span></a>';
                            echo '<a href="delete_order.php?id=' . $row['id'] . '" title="Delete Record" data-toggle="tooltip"><span class="fa fa-trash"></span></a>';
                            echo "</td>";
                            echo "</tr>";
                        }
                        echo "</tbody>";
                        echo "</table>";

                        // Display pagination links
                        echo '<ul class="pagination">';
                        if ($currentPage > 1) {
                            echo '<li class="page-item"><a class="page-link" href="?page=' . ($currentPage - 1) . '">Previous</a></li>';
                        }
                        for ($i = 1; $i <= $totalPages; $i++) {
                            echo '<li class="page-item ';
                            if ($i == $currentPage) {
                                echo 'active';
                            }
                            echo '"><a class="page-link" href="?page=' . $i . '">' . $i . '</a></li>';
                        }
                        if ($currentPage < $totalPages) {
                            echo '<li class="page-item"><a class="page-link" href="?page=' . ($currentPage + 1) . '">Next</a></li>';
                        }
                        echo '</ul>';
                    } else {
                        echo '<div class="alert alert-danger"><em>No orders found.</em></div>';
                    }

                    // Close connection
                    mysqli_close($link);
                    ?>


                    </div>
                </div>
            </div>
        </div>
</body>

</html>