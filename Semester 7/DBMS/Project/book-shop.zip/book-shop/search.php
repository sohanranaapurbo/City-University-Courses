<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
        .wrapper {
            width: 70%;
            margin: 0 auto;
            background-color: #AFD3E2;
            border-radius: 12px;
        }

        table tr td:last-child {
            width: 120px;
        }

        table {
            background-color: #E6FFFD;
            /* border-radius: 12px; */
        }

        /* Dashboard */
        .navbar {
            background-color: #343a40;
            padding: 10px 20px;
        }

        .navbar-brand {
            color: #fff;
            font-size: 24px;
        }

        .navbar-nav .nav-link {
            color: #fff;
            font-size: 16px;
            padding: 5px 10px;
        }

        .dashboard {
            display: flex;
        }

        .sidebar {
            width: 30%;
            height: 600px;
            background-color: #E6FFFD;
            padding: 20px;
            border-radius: 12px;
            margin-right: 8px;
        }

        .sidebar h4 {
            margin-bottom: 20px;
            padding: 2px 8px;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar li {
            margin-bottom: 10px;
            padding: 2px 8px;
        }

        .sidebar_li_selected,
        .sidebar_li_unselected:hover {
            margin-bottom: 10px;
            font-weight: bold;
            background-color: #AFD3E2;
            border-radius: 12px;
        }

        .sidebar a {
            text-decoration: none;
            color: #212529;
        }

        .content {
            flex-grow: 1;
            padding: 20px;
        }

        .content h2 {
            margin-bottom: 20px;
        }
    </style>
    <script>
        $(document).ready(function () {
            $('[data-toggle="tooltip"]').tooltip();
        });
    </script>
</head>

<body>

    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand" href="#">Admin dashboard</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Logout (Tahmeedul)</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <br>

    <div class="container dashboard">

        <div class="sidebar">
            <h4>Menu</h4>
            <ul>
                <li class="sidebar_li_selected"><a href="search.php">Search Book</a></li>
                <li class="sidebar_li_unselected"><a href="index.php">Manage Books</a></li>
                <li class="sidebar_li_unselected"><a href="orders.php">Manage Orders</a></li>
            </ul>
        </div>

        <div class="wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="mt-5 mb-3 clearfix">

                            <div class="input-group mb-3">
                                <input type="text" id="search-input" class="form-control"
                                    placeholder="Search by name, writer, or category">
                                <div class="input-group-append">
                                    <button id="search-button" class="btn btn-primary" type="button"><i
                                            class="fa fa-search"></i> Search</button>
                                </div>
                            </div>


                        </div>

                        <div id="search-results"></div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <script>
        $(document).ready(function () {

            // Search button click event
            $("#search-button").click(function () {
                var searchQuery = $("#search-input").val().trim();
                searchBooks(searchQuery);
            });

            // Search input enter key press event
            $("#search-input").keypress(function (e) {
                if (e.which === 13) {
                    var searchQuery = $(this).val().trim();
                    searchBooks(searchQuery);
                }
            });

            // Function to search books
            function searchBooks(query) {
                $.ajax({
                    url: "search_books.php",
                    type: "POST",
                    data: {
                        query: query,
                        page: 1
                    },
                    beforeSend: function () {
                        $("#search-results").html(
                            '<tr><td colspan="6" class="text-center">Searching...</td></tr>');
                    },
                    success: function (response) {
                        $("#search-results").html(response);
                    },
                    error: function () {
                        $("#search-results").html(
                            '<tr><td colspan="6" class="text-center">Error occurred while searching.</td></tr>'
                        );
                    }
                });
            }


            // Function to search books for a specific page
            function searchBooksPage(query, page) {
                $.ajax({
                    url: "search_books.php",
                    type: "POST",
                    data: {
                        query: query,
                        page: page
                    },
                    beforeSend: function () {
                        $("#search-results").html('<tr><td colspan="6" class="text-center">Searching...</td></tr>');
                    },
                    success: function (response) {
                        $("#search-results").html(response);
                    },
                    error: function () {
                        $("#search-results").html('<tr><td colspan="6" class="text-center">Error occurred while searching.</td></tr>');
                    }
                });
            }
        });
    </script>
</body>
</html>